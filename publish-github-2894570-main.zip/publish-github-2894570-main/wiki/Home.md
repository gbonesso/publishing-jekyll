---
title: StarGazers
img: images/group.svg
layout: base.njk
---

![{{title}}]({{img}}){class="img-fluid "}

The Stargazers are members of the _Intergalactic Alliance_ paving the way for peace and benevolence among all species. They are known for their enthusiasm for science, for their love of fun, and their dedication to education.

# Communication

Stargazers are fluent in **JavaScript**, so once you connect to their network, simply type in a message into their console.

```js
console.log("Take me to your leader");
```
